// Vercel's servers run in UTC, but this store operates on Bangladesh
// time (Asia/Dhaka, UTC+6). Without this, "today" computed via
// `new Date().toISOString()` would roll over to the next/previous
// calendar day up to 6 hours off from the shop's actual day.

export function bdToday(): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Dhaka",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date()); // en-CA formats as YYYY-MM-DD
}

export function bdMonth(): string {
  return bdToday().slice(0, 7);
}
