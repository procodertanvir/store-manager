import { sql } from "@vercel/postgres";

export type Product = {
  id: number;
  name: string;
  category: string;
  unit: string;
  price: number;
  stock: number;
  low_stock: number;
  created_at: string;
};

export type Customer = {
  id: number;
  name: string;
  phone: string | null;
  address: string | null;
  note: string | null;
  created_at: string;
};

export type Sale = {
  id: number;
  date: string; // YYYY-MM-DD
  product_id: number;
  product_name: string;
  category: string;
  qty: number;
  unit_price: number;
  total: number;
  customer_id: number | null;
  customer_name: string | null;
  created_at: string;
};

let initialized = false;

/**
 * Creates the tables if they don't exist yet. Safe to call on every
 * request — the CREATE TABLE IF NOT EXISTS calls are cheap once the
 * schema exists. We memoize per server instance so we don't run it on
 * every single request.
 */
export async function ensureSchema() {
  if (initialized) return;

  await sql`
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Other',
      unit TEXT NOT NULL DEFAULT 'pcs',
      price NUMERIC NOT NULL DEFAULT 0,
      stock NUMERIC NOT NULL DEFAULT 0,
      low_stock NUMERIC NOT NULL DEFAULT 5,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS customers (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      note TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS sales (
      id SERIAL PRIMARY KEY,
      date DATE NOT NULL,
      product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
      product_name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Other',
      qty NUMERIC NOT NULL,
      unit_price NUMERIC NOT NULL,
      total NUMERIC NOT NULL,
      customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
      customer_name TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;

  await sql`CREATE INDEX IF NOT EXISTS sales_date_idx ON sales (date);`;

  initialized = true;
}
