"use client";

import { useEffect, useState } from "react";

type Customer = {
  id: number;
  name: string;
  phone: string | null;
  address: string | null;
  note: string | null;
};

const emptyForm = { name: "", phone: "", address: "", note: "" };

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);
  const [form, setForm] = useState(emptyForm);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/customers", { cache: "no-store" });
    setCustomers(await res.json());
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  function openNew() {
    setEditing(null);
    setForm(emptyForm);
    setShowForm(true);
  }
  function openEdit(c: Customer) {
    setEditing(c);
    setForm({ name: c.name, phone: c.phone || "", address: c.address || "", note: c.note || "" });
    setShowForm(true);
  }

  async function save() {
    if (!form.name.trim()) return alert("Customer name is required");
    if (editing) {
      await fetch(`/api/customers/${editing.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
    } else {
      await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
    }
    setShowForm(false);
    load();
  }

  async function remove(c: Customer) {
    if (!confirm(`Delete "${c.name}"?`)) return;
    await fetch(`/api/customers/${c.id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">Customers</h1>
          <p className="text-sm text-gray-500">Everyone your store keeps in touch with</p>
        </div>
        <button className="btn btn-primary" onClick={openNew}>
          + Add customer
        </button>
      </div>

      {loading ? (
        <p className="text-gray-500">Loading…</p>
      ) : customers.length === 0 ? (
        <div className="card p-10 text-center text-gray-500">No customers yet.</div>
      ) : (
        <div className="card">
          <div className="p-4">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {customers.map((c) => (
                  <tr key={c.id}>
                    <td>
                      {c.name}
                      {c.note && <div className="text-xs text-gray-400">{c.note}</div>}
                    </td>
                    <td className="text-gray-500">{c.phone || "—"}</td>
                    <td className="text-gray-500">{c.address || "—"}</td>
                    <td className="whitespace-nowrap">
                      <button className="text-sm mr-2" onClick={() => openEdit(c)}>
                        ✏️
                      </button>
                      <button className="text-sm" onClick={() => remove(c)}>
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="card p-5 w-full max-w-md">
            <h2 className="text-lg font-bold mb-4">{editing ? "Edit customer" : "New customer"}</h2>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-500">Name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-gray-500">Phone</label>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-gray-500">Address</label>
                <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-gray-500">Note</label>
                <textarea value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button className="btn btn-ghost flex-1" onClick={() => setShowForm(false)}>
                Cancel
              </button>
              <button className="btn btn-primary flex-1" onClick={save}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
