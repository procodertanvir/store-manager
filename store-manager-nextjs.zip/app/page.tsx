"use client";

import { useEffect, useState } from "react";

function money(n: number) {
  return "$" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
}

export default function DashboardPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/dashboard", { cache: "no-store" });
    setData(await res.json());
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  if (loading || !data) {
    return <p className="text-gray-500">Loading…</p>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Dashboard</h1>
      <p className="text-sm text-gray-500 mb-6">Today's snapshot</p>

      {data.lowStock.length > 0 && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4">
          <b className="text-red-700">{data.lowStock.length} product(s) are low on stock</b>
          <ul className="flex flex-wrap gap-2 mt-2">
            {data.lowStock.slice(0, 10).map((p: any) => (
              <li key={p.id} className="bg-white border border-red-200 rounded-full px-3 py-1 text-sm">
                {p.name} — {p.stock} {p.unit} left
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <div className="card p-4 bg-maroon text-white">
          <div className="text-xs opacity-80 mb-1">Today's sales</div>
          <div className="text-2xl font-bold">{money(data.todayTotal)}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-gray-500 mb-1">This month's sales</div>
          <div className="text-2xl font-bold">{money(data.monthTotal)}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-gray-500 mb-1">Total products</div>
          <div className="text-2xl font-bold">{data.productsCount}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-gray-500 mb-1">Total customers</div>
          <div className="text-2xl font-bold">{data.customersCount}</div>
        </div>
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 font-semibold flex items-center justify-between">
          Today's sales entries ({data.todaySales.length})
          <button className="text-sm text-gray-400 hover:text-gray-700" onClick={load}>
            ↻ Refresh
          </button>
        </div>
        <div className="p-4">
          {data.todaySales.length === 0 ? (
            <p className="text-gray-500 text-center py-6">No sales recorded yet today.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Customer</th>
                </tr>
              </thead>
              <tbody>
                {data.todaySales.map((s: any) => (
                  <tr key={s.id}>
                    <td>{s.product_name}</td>
                    <td>{s.qty}</td>
                    <td>{money(Number(s.total))}</td>
                    <td className="text-gray-500">{s.customer_name || "Walk-in"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
