"use client";

import { useEffect, useState } from "react";

type Product = {
  id: number;
  name: string;
  category: string;
  unit: string;
  price: number;
  stock: number;
  low_stock: number;
};

function money(n: number) {
  return "$" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
}

const emptyForm = { name: "", category: "", unit: "pcs", price: "", stock: "", low_stock: "5" };

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [filterCat, setFilterCat] = useState("All");
  const [search, setSearch] = useState("");

  async function load() {
    setLoading(true);
    const res = await fetch("/api/products", { cache: "no-store" });
    setProducts(await res.json());
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, []);

  function openNew() {
    setEditing(null);
    setForm(emptyForm);
    setShowForm(true);
  }
  function openEdit(p: Product) {
    setEditing(p);
    setForm({
      name: p.name,
      category: p.category,
      unit: p.unit,
      price: String(p.price),
      stock: String(p.stock),
      low_stock: String(p.low_stock),
    });
    setShowForm(true);
  }

  async function save() {
    if (!form.name.trim()) return alert("Product name is required");
    const payload = {
      name: form.name.trim(),
      category: form.category.trim() || "Other",
      unit: form.unit.trim() || "pcs",
      price: Number(form.price) || 0,
      stock: Number(form.stock) || 0,
      low_stock: Number(form.low_stock) || 5,
    };
    if (editing) {
      await fetch(`/api/products/${editing.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } else {
      await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    }
    setShowForm(false);
    load();
  }

  async function remove(p: Product) {
    if (!confirm(`Delete "${p.name}"?`)) return;
    await fetch(`/api/products/${p.id}`, { method: "DELETE" });
    load();
  }

  const categories = ["All", ...Array.from(new Set(products.map((p) => p.category)))];
  const filtered = products.filter(
    (p) =>
      (filterCat === "All" || p.category === filterCat) &&
      (!search || p.name.toLowerCase().includes(search.toLowerCase()))
  );
  const groups: Record<string, Product[]> = {};
  filtered.forEach((p) => {
    (groups[p.category] = groups[p.category] || []).push(p);
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">Products & Stock</h1>
          <p className="text-sm text-gray-500">Grouped by category</p>
        </div>
        <button className="btn btn-primary" onClick={openNew}>
          + Add product
        </button>
      </div>

      <input
        placeholder="Search products…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-3"
      />
      <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilterCat(c)}
            className={`px-3 py-1.5 rounded-full text-sm border whitespace-nowrap ${
              filterCat === c ? "bg-maroon text-white border-maroon" : "bg-white border-gray-200"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="text-gray-500">Loading…</p>
      ) : products.length === 0 ? (
        <div className="card p-10 text-center text-gray-500">No products yet. Add your first one.</div>
      ) : (
        Object.entries(groups).map(([cat, items]) => (
          <div key={cat} className="card mb-4">
            <div className="p-4 border-b border-gray-100 font-semibold">
              🏷️ {cat}{" "}
              <span className="text-gray-400 font-normal text-sm">
                ({items.length} items · total stock {items.reduce((a, p) => a + Number(p.stock), 0)})
              </span>
            </div>
            <div className="p-4">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((p) => {
                    const low = Number(p.stock) <= Number(p.low_stock);
                    return (
                      <tr key={p.id} className={low ? "bg-red-50" : ""}>
                        <td>
                          {p.name}
                          <div className="text-xs text-gray-400">per {p.unit}</div>
                        </td>
                        <td>{money(p.price)}</td>
                        <td>
                          <span className={`badge ${low ? "badge-low" : "badge-ok"}`}>
                            {p.stock} {p.unit}
                          </span>
                        </td>
                        <td className="whitespace-nowrap">
                          <button className="text-sm mr-2" onClick={() => openEdit(p)}>
                            ✏️
                          </button>
                          <button className="text-sm" onClick={() => remove(p)}>
                            🗑️
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ))
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
          <div className="card p-5 w-full max-w-md">
            <h2 className="text-lg font-bold mb-4">{editing ? "Edit product" : "New product"}</h2>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-500">Name</label>
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-gray-500">Category</label>
                <input
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  list="cats"
                />
                <datalist id="cats">
                  {Array.from(new Set(products.map((p) => p.category))).map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="text-xs text-gray-500">Unit</label>
                  <input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
                </div>
                <div className="flex-1">
                  <label className="text-xs text-gray-500">Price per unit</label>
                  <input
                    type="number"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="text-xs text-gray-500">Current stock</label>
                  <input
                    type="number"
                    value={form.stock}
                    onChange={(e) => setForm({ ...form, stock: e.target.value })}
                  />
                </div>
                <div className="flex-1">
                  <label className="text-xs text-gray-500">Low-stock alert level</label>
                  <input
                    type="number"
                    value={form.low_stock}
                    onChange={(e) => setForm({ ...form, low_stock: e.target.value })}
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button className="btn btn-ghost flex-1" onClick={() => setShowForm(false)}>
                Cancel
              </button>
              <button className="btn btn-primary flex-1" onClick={save}>
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
