"use client";

import { useEffect, useMemo, useState } from "react";

type Product = { id: number; name: string; price: number; stock: number; unit: string };
type Customer = { id: number; name: string };
type Sale = {
  id: number;
  date: string;
  product_name: string;
  qty: number;
  total: number;
  customer_name: string | null;
};

function money(n: number) {
  return "$" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
}
function today() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(new Date());
}

export default function SalesPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [productId, setProductId] = useState<string>("");
  const [qty, setQty] = useState("1");
  const [price, setPrice] = useState("");
  const [customerId, setCustomerId] = useState("");
  const [date, setDate] = useState(today());

  async function loadAll() {
    const [p, c, s] = await Promise.all([
      fetch("/api/products", { cache: "no-store" }).then((r) => r.json()),
      fetch("/api/customers", { cache: "no-store" }).then((r) => r.json()),
      fetch("/api/sales?limit=15", { cache: "no-store" }).then((r) => r.json()),
    ]);
    setProducts(p);
    setCustomers(c);
    setSales(s);
    if (p.length && !productId) {
      setProductId(String(p[0].id));
      setPrice(String(p[0].price));
    }
  }
  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedProduct = products.find((p) => String(p.id) === productId);
  const total = useMemo(() => (Number(qty) || 0) * (Number(price) || 0), [qty, price]);

  function onProductChange(id: string) {
    setProductId(id);
    const p = products.find((pr) => String(pr.id) === id);
    if (p) setPrice(String(p.price));
  }

  async function submitSale() {
    if (!selectedProduct) return;
    const q = Number(qty);
    if (!q || q <= 0) return alert("Enter a valid quantity");
    if (q > Number(selectedProduct.stock)) {
      return alert(`Not enough stock — only ${selectedProduct.stock} ${selectedProduct.unit} left`);
    }
    const res = await fetch("/api/sales", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_id: Number(productId),
        qty: q,
        unit_price: Number(price),
        customer_id: customerId ? Number(customerId) : null,
        date,
      }),
    });
    if (!res.ok) {
      const err = await res.json();
      return alert(err.error || "Could not record sale");
    }
    setQty("1");
    loadAll();
  }

  async function removeSale(id: number) {
    if (!confirm("Delete this sale? Stock will be restored.")) return;
    await fetch(`/api/sales/${id}`, { method: "DELETE" });
    loadAll();
  }

  if (products.length === 0) {
    return (
      <div className="card p-10 text-center text-gray-500">
        Add at least one product before recording a sale.
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-1">Record Sale</h1>
      <p className="text-sm text-gray-500 mb-6">Add a new sale entry</p>

      <div className="card p-5 mb-6 max-w-lg">
        <div className="mb-3">
          <label className="text-xs text-gray-500">Product</label>
          <select value={productId} onChange={(e) => onProductChange(e.target.value)}>
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} — {p.stock} {p.unit} in stock
              </option>
            ))}
          </select>
        </div>
        <div className="flex gap-3 mb-3">
          <div className="flex-1">
            <label className="text-xs text-gray-500">Quantity</label>
            <input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} />
          </div>
          <div className="flex-1">
            <label className="text-xs text-gray-500">Unit price</label>
            <input type="number" step="0.01" value={price} onChange={(e) => setPrice(e.target.value)} />
          </div>
        </div>
        <div className="flex gap-3 mb-3">
          <div className="flex-1">
            <label className="text-xs text-gray-500">Customer (optional)</label>
            <select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
              <option value="">Walk-in</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="text-xs text-gray-500">Date</label>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
        </div>
        <div className="flex justify-between items-center bg-gray-50 rounded-lg px-4 py-3 my-3">
          <span className="text-gray-500 text-sm">Total</span>
          <b className="text-lg">{money(total)}</b>
        </div>
        <button className="btn btn-primary w-full justify-center" onClick={submitSale}>
          Add sale
        </button>
      </div>

      <div className="card">
        <div className="p-4 border-b border-gray-100 font-semibold">Recent sales</div>
        <div className="p-4">
          {sales.length === 0 ? (
            <p className="text-gray-500 text-center py-6">No sales recorded yet.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Product</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Customer</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {sales.map((s) => (
                  <tr key={s.id}>
                    <td className="text-gray-500">{s.date}</td>
                    <td>{s.product_name}</td>
                    <td>{s.qty}</td>
                    <td>{money(s.total)}</td>
                    <td className="text-gray-500">{s.customer_name || "—"}</td>
                    <td>
                      <button className="text-sm" onClick={() => removeSale(s.id)}>
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
