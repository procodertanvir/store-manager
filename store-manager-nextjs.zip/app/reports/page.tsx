"use client";

import { useEffect, useState } from "react";

function money(n: number) {
  return "$" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
}
function today() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(new Date());
}
function thisMonth() {
  return today().slice(0, 7);
}

export default function ReportsPage() {
  const [mode, setMode] = useState<"daily" | "monthly">("daily");
  const [date, setDate] = useState(today());
  const [month, setMonth] = useState(thisMonth());
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const url =
      mode === "daily" ? `/api/reports?type=daily&date=${date}` : `/api/reports?type=monthly&month=${month}`;
    fetch(url, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        setData(d);
        setLoading(false);
      });
  }, [mode, date, month]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Reports</h1>
          <p className="text-sm text-gray-500">Daily and monthly sales</p>
        </div>
        <div className="inline-flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setMode("daily")}
            className={`px-4 py-1.5 rounded-md text-sm ${mode === "daily" ? "bg-white shadow font-semibold" : "text-gray-500"}`}
          >
            Daily
          </button>
          <button
            onClick={() => setMode("monthly")}
            className={`px-4 py-1.5 rounded-md text-sm ${mode === "monthly" ? "bg-white shadow font-semibold" : "text-gray-500"}`}
          >
            Monthly
          </button>
        </div>
      </div>

      <div className="card p-4 mb-4 flex items-center gap-3">
        {mode === "daily" ? (
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-auto" />
        ) : (
          <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="w-auto" />
        )}
      </div>

      {loading || !data ? (
        <p className="text-gray-500">Loading…</p>
      ) : mode === "daily" ? (
        <DailyView data={data} />
      ) : (
        <MonthlyView data={data} month={month} />
      )}
    </div>
  );
}

function DailyView({ data }: { data: any }) {
  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        <Stat label="Total sales" value={money(data.total)} accent />
        <Stat label="Items sold" value={String(data.qtyTotal)} />
        <Stat label="Entries" value={String(data.sales.length)} />
      </div>
      {Object.keys(data.byCategory).length > 0 && (
        <div className="card mb-4">
          <div className="p-4 border-b border-gray-100 font-semibold">By category</div>
          <div className="p-4">
            <table>
              <tbody>
                {Object.entries(data.byCategory)
                  .sort((a: any, b: any) => b[1] - a[1])
                  .map(([c, v]: any) => (
                    <tr key={c}>
                      <td>{c}</td>
                      <td>{money(v)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <div className="card">
        <div className="p-4 border-b border-gray-100 font-semibold">Details</div>
        <div className="p-4">
          {data.sales.length === 0 ? (
            <p className="text-gray-500 text-center py-6">No sales on this day.</p>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Qty</th>
                  <th>Total</th>
                  <th>Customer</th>
                </tr>
              </thead>
              <tbody>
                {data.sales.map((s: any) => (
                  <tr key={s.id}>
                    <td>{s.product_name}</td>
                    <td>{s.qty}</td>
                    <td>{money(s.total)}</td>
                    <td className="text-gray-500">{s.customer_name || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}

function MonthlyView({ data, month }: { data: any; month: string }) {
  const [y, m] = month.split("-").map(Number);
  const nDays = new Date(y, m, 0).getDate();
  const perDay = Array.from({ length: nDays }, (_, i) => {
    const d = String(i + 1).padStart(2, "0");
    return data.perDay[`${month}-${d}`] || 0;
  });
  const maxDay = Math.max(1, ...perDay);
  const topProducts = Object.entries(data.byProduct || {})
    .sort((a: any, b: any) => b[1] - a[1])
    .slice(0, 6);

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
        <Stat label="Total sales" value={money(data.total)} accent />
        <Stat label="Items sold" value={String(data.qtyTotal)} />
        <Stat label="Daily average" value={money(data.total / nDays)} />
      </div>

      <div className="card mb-4">
        <div className="p-4 border-b border-gray-100 font-semibold">Sales by day</div>
        <div className="p-4 flex items-end gap-1 h-32">
          {perDay.map((v, i) => (
            <div key={i} className="flex-1 flex flex-col items-center justify-end h-full" title={`Day ${i + 1}: ${money(v)}`}>
              <div
                className="w-full bg-gold rounded-t"
                style={{ height: `${Math.max(2, (v / maxDay) * 100)}px` }}
              />
            </div>
          ))}
        </div>
      </div>

      {Object.keys(data.byCategory || {}).length > 0 && (
        <div className="card mb-4">
          <div className="p-4 border-b border-gray-100 font-semibold">By category</div>
          <div className="p-4">
            <table>
              <tbody>
                {Object.entries(data.byCategory)
                  .sort((a: any, b: any) => b[1] - a[1])
                  .map(([c, v]: any) => (
                    <tr key={c}>
                      <td>{c}</td>
                      <td>{money(v)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {topProducts.length > 0 && (
        <div className="card">
          <div className="p-4 border-b border-gray-100 font-semibold">Best-selling products</div>
          <div className="p-4">
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Qty sold</th>
                </tr>
              </thead>
              <tbody>
                {topProducts.map(([n, q]: any) => (
                  <tr key={n}>
                    <td>{n}</td>
                    <td>{q}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={`card p-4 ${accent ? "bg-maroon text-white" : ""}`}>
      <div className={`text-xs mb-1 ${accent ? "opacity-80" : "text-gray-500"}`}>{label}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  );
}
