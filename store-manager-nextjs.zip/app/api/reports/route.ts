import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { bdToday, bdMonth } from "@/lib/date";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  await ensureSchema();
  const { searchParams } = new URL(req.url);
  const type = searchParams.get("type") || "daily";

  if (type === "daily") {
    const date = searchParams.get("date") || bdToday();
    const { rows } = await sql`SELECT * FROM sales WHERE date = ${date} ORDER BY created_at;`;
    const total = rows.reduce((a, s) => a + Number(s.total), 0);
    const qtyTotal = rows.reduce((a, s) => a + Number(s.qty), 0);
    const byCategory: Record<string, number> = {};
    rows.forEach((s) => {
      byCategory[s.category] = (byCategory[s.category] || 0) + Number(s.total);
    });
    return NextResponse.json({ date, sales: rows, total, qtyTotal, byCategory });
  }

  if (type === "monthly") {
    const month = searchParams.get("month") || bdMonth();
    const { rows } = await sql`
      SELECT * FROM sales WHERE to_char(date, 'YYYY-MM') = ${month} ORDER BY date;
    `;
    const total = rows.reduce((a, s) => a + Number(s.total), 0);
    const qtyTotal = rows.reduce((a, s) => a + Number(s.qty), 0);
    const byCategory: Record<string, number> = {};
    const byProduct: Record<string, number> = {};
    const perDay: Record<string, number> = {};
    rows.forEach((s) => {
      byCategory[s.category] = (byCategory[s.category] || 0) + Number(s.total);
      byProduct[s.product_name] = (byProduct[s.product_name] || 0) + Number(s.qty);
      const day = String(s.date).slice(0, 10);
      perDay[day] = (perDay[day] || 0) + Number(s.total);
    });
    return NextResponse.json({ month, total, qtyTotal, byCategory, byProduct, perDay, count: rows.length });
  }

  return NextResponse.json({ error: "Unknown report type" }, { status: 400 });
}
