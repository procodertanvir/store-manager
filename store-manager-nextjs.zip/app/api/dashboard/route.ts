import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { bdToday, bdMonth } from "@/lib/date";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSchema();

  const today = bdToday();
  const month = bdMonth();

  const [productsRes, customersRes, todaySalesRes, monthSalesRes] = await Promise.all([
    sql`SELECT * FROM products ORDER BY name;`,
    sql`SELECT id FROM customers;`,
    sql`SELECT * FROM sales WHERE date = ${today} ORDER BY created_at DESC;`,
    sql`SELECT COALESCE(SUM(total),0) AS total FROM sales WHERE to_char(date,'YYYY-MM') = ${month};`,
  ]);

  const products = productsRes.rows;
  const lowStock = products
    .filter((p) => Number(p.stock) <= Number(p.low_stock))
    .sort((a, b) => Number(a.stock) - Number(b.stock));

  return NextResponse.json({
    productsCount: products.length,
    customersCount: customersRes.rows.length,
    lowStock,
    todaySales: todaySalesRes.rows,
    todayTotal: todaySalesRes.rows.reduce((a, s) => a + Number(s.total), 0),
    monthTotal: Number(monthSalesRes.rows[0]?.total || 0),
  });
}
