import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  await ensureSchema();
  const id = Number(params.id);
  const body = await req.json();
  const { name, phone, address, note } = body;

  const { rows } = await sql`
    UPDATE customers
    SET name = ${name}, phone = ${phone || null}, address = ${address || null}, note = ${note || null}
    WHERE id = ${id}
    RETURNING *;
  `;
  if (!rows[0]) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(rows[0]);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  await ensureSchema();
  const id = Number(params.id);
  await sql`DELETE FROM customers WHERE id = ${id};`;
  return NextResponse.json({ ok: true });
}
