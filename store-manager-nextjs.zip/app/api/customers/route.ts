import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSchema();
  const { rows } = await sql`SELECT * FROM customers ORDER BY name;`;
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const body = await req.json();
  const { name, phone, address, note } = body;

  if (!name || typeof name !== "string") {
    return NextResponse.json({ error: "Customer name is required" }, { status: 400 });
  }

  const { rows } = await sql`
    INSERT INTO customers (name, phone, address, note)
    VALUES (${name}, ${phone || null}, ${address || null}, ${note || null})
    RETURNING *;
  `;
  return NextResponse.json(rows[0], { status: 201 });
}
