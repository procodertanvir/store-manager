import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { bdToday } from "@/lib/date";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  await ensureSchema();
  const { searchParams } = new URL(req.url);
  const limit = Number(searchParams.get("limit") || 50);
  const { rows } = await sql`
    SELECT * FROM sales ORDER BY date DESC, created_at DESC LIMIT ${limit};
  `;
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const body = await req.json();
  const { product_id, qty, unit_price, customer_id, date } = body;

  if (!product_id || !qty || qty <= 0) {
    return NextResponse.json({ error: "product_id and a positive qty are required" }, { status: 400 });
  }

  const productRes = await sql`SELECT * FROM products WHERE id = ${product_id};`;
  const product = productRes.rows[0];
  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }
  if (Number(product.stock) < Number(qty)) {
    return NextResponse.json(
      { error: `Not enough stock — only ${product.stock} ${product.unit} left` },
      { status: 400 }
    );
  }

  let customerName: string | null = null;
  if (customer_id) {
    const custRes = await sql`SELECT name FROM customers WHERE id = ${customer_id};`;
    customerName = custRes.rows[0]?.name || null;
  }

  const price = unit_price ?? product.price;
  const total = Number(price) * Number(qty);
  const saleDate = date || bdToday();

  const { rows } = await sql`
    INSERT INTO sales (date, product_id, product_name, category, qty, unit_price, total, customer_id, customer_name)
    VALUES (${saleDate}, ${product.id}, ${product.name}, ${product.category}, ${qty}, ${price}, ${total}, ${customer_id || null}, ${customerName})
    RETURNING *;
  `;

  await sql`UPDATE products SET stock = stock - ${qty} WHERE id = ${product.id};`;

  return NextResponse.json(rows[0], { status: 201 });
}
