import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  await ensureSchema();
  const id = Number(params.id);

  const saleRes = await sql`SELECT * FROM sales WHERE id = ${id};`;
  const sale = saleRes.rows[0];
  if (!sale) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await sql`DELETE FROM sales WHERE id = ${id};`;
  if (sale.product_id) {
    await sql`UPDATE products SET stock = stock + ${sale.qty} WHERE id = ${sale.product_id};`;
  }
  return NextResponse.json({ ok: true });
}
