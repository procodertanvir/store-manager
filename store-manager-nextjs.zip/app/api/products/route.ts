import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSchema();
  const { rows } = await sql`SELECT * FROM products ORDER BY category, name;`;
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const body = await req.json();
  const { name, category, unit, price, stock, low_stock } = body;

  if (!name || typeof name !== "string") {
    return NextResponse.json({ error: "Product name is required" }, { status: 400 });
  }

  const { rows } = await sql`
    INSERT INTO products (name, category, unit, price, stock, low_stock)
    VALUES (${name}, ${category || "Other"}, ${unit || "pcs"}, ${price || 0}, ${stock || 0}, ${low_stock ?? 5})
    RETURNING *;
  `;
  return NextResponse.json(rows[0], { status: 201 });
}
