import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  await ensureSchema();
  const id = Number(params.id);
  const body = await req.json();
  const { name, category, unit, price, stock, low_stock } = body;

  const { rows } = await sql`
    UPDATE products
    SET name = ${name}, category = ${category || "Other"}, unit = ${unit || "pcs"},
        price = ${price || 0}, stock = ${stock || 0}, low_stock = ${low_stock ?? 5}
    WHERE id = ${id}
    RETURNING *;
  `;
  if (!rows[0]) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(rows[0]);
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  await ensureSchema();
  const id = Number(params.id);
  await sql`DELETE FROM products WHERE id = ${id};`;
  return NextResponse.json({ ok: true });
}
