"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/", label: "Dashboard", icon: "📊" },
  { href: "/products", label: "Products & Stock", icon: "📦" },
  { href: "/customers", label: "Customers", icon: "👥" },
  { href: "/sales", label: "Record Sale", icon: "🧾" },
  { href: "/reports", label: "Reports", icon: "📈" },
];

export default function Nav() {
  const pathname = usePathname();
  return (
    <div className="w-[220px] shrink-0 bg-maroon text-[#F3E7DA] p-4 flex flex-col min-h-screen">
      <div className="flex items-center gap-2 px-2 pb-6">
        <span className="text-2xl">🏪</span>
        <div>
          <div className="font-bold text-[17px] leading-tight">My Store</div>
          <div className="text-[11px] opacity-70">Store Manager</div>
        </div>
      </div>
      <nav className="flex flex-col gap-1">
        {links.map((l) => {
          const active = pathname === l.href;
          return (
            <Link
              key={l.href}
              href={l.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-[15px] ${
                active ? "bg-white/15 font-semibold opacity-100" : "opacity-80 hover:opacity-100"
              }`}
            >
              <span className="w-5 text-center">{l.icon}</span>
              {l.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
